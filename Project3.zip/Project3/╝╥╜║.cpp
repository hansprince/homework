#include<stdio.h>
int recfact(int n) {
	if (n == 1)
		return 1;
	else
		return n + recfact(n - 1);
}
void main() {
	printf("%d", recfact(100));
}